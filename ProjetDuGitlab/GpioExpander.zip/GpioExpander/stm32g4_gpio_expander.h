/*
 * stm32g4_gpio_expander.h
 *
 *  Created on: 27 avr. 2026
 *      Author: Alice GEDOUX
 */

#ifndef STM32G4_GPIO_EXPANDER_H_
#define STM32G4_GPIO_EXPANDER_H_

void initialisationGPIOExpander(void);
void initialisationClavierMatriciel(void);

#endif /* STM32G4_GPIO_EXPANDER_H_ */
