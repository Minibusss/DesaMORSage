/*
 * stm32g4_gpio_expander.c
 *
 *  Created on: 27 avr. 2026
 *      Author: Alice GEDOUX
 */

#include "stm32g4_mcp23s17.h"
#include "stm32g4_gpio_expander.h"
#include <stdint.h>

/**
 * @brief La fonction permet d'initialiser le gpio expander
 * @param Rien
 * @retval Rien
 */
void initialisationGPIOExpander(void){
	BSP_MCP23S17_init();//Initialiser le gpioexpander
}

/**
 * @brief La fonction permet d'initialiser les pins du gpio expander pour le clavier matriciel
 * @param Rien
 * @retval Rien
 */
void initialisationClavierMatriciel(void){
	//GPIOA0 -> GPIOA3 (input)
	BSP_MCP23S17_setGPIODirection(MCP23S17_PORT_A, MCP23S17_PIN_0, MCP23S17_DIRECTION_INPUT);
	BSP_MCP23S17_setGPIODirection(MCP23S17_PORT_A, MCP23S17_PIN_1, MCP23S17_DIRECTION_INPUT);
	BSP_MCP23S17_setGPIODirection(MCP23S17_PORT_A, MCP23S17_PIN_2, MCP23S17_DIRECTION_INPUT);
	BSP_MCP23S17_setGPIODirection(MCP23S17_PORT_A, MCP23S17_PIN_3, MCP23S17_DIRECTION_INPUT);

	//GPIOA4 -> GPIO7 (output)
	BSP_MCP23S17_setGPIODirection(MCP23S17_PORT_A,  MCP23S17_PIN_4,  MCP23S17_DIRECTION_OUTPUT);
	BSP_MCP23S17_setGPIODirection(MCP23S17_PORT_A,  MCP23S17_PIN_5,  MCP23S17_DIRECTION_OUTPUT);
	BSP_MCP23S17_setGPIODirection(MCP23S17_PORT_A,  MCP23S17_PIN_6,  MCP23S17_DIRECTION_OUTPUT);
	BSP_MCP23S17_setGPIODirection(MCP23S17_PORT_A,  MCP23S17_PIN_7,  MCP23S17_DIRECTION_OUTPUT);
}
