/*
 * stm32g4_clavier_matriciel.c
 *
 *  Created on: 27 avr. 2026
 *      Author: Alice GEDOUX
 */
#include "stm32g4_mcp23s17.h"
#include "stm32g4_matrix_keyboard.h"

typedef struct {
	uint8_t pinInputGPIO;
	uint8_t pinOutputGPIO;
	uint8_t chaine;
}ClavierCode;

ClavierCode listeClavierCode = {
		{0b00000001,0b00010000,"1"},
		{0b00000001,0b00100000,"2"},
		{0b00000001,0b01000000,"3"},
		{0b00000001,0b10000000,"A"},

		{0b00000010,0b00010000,"4"},
		{0b00000010,0b00100000,"5"},
		{0b00000010,0b01000000,"6"},
		{0b00000010,0b10000000,"B"},

		{0b00000100,0b00010000,"7"},
		{0b00000100,0b00100000,"8"},
		{0b00000100,0b01000000,"9"},
		{0b00000100,0b10000000,"C"},

		{0b00001000,0b00010000,"*"},
		{0b00001000,0b00100000,"0"},
		{0b00001000,0b01000000,"#"},
		{0b00001000,0b10000000,"D"}
};
- clavier matriciel : ecrire sur les pins en entrée -> void BSP_MCP23S17_writeGPIO(MCP23S17_port_e port, MCP23S17_pin_e pin, MCP23S17_pinState_e state)
- clavier matriciel : lire les sorties uint8_t BSP_MCP23S17_readGPIO(MCP23S17_port_e port) :
@return l'état des GPIO sur 8 bits (1 bit par GPIO)-> en fonction du code binaire il faudra le comparer
		à une structure puis "stocker" le code converti en chaine de cara et renvoyer le mdp à gestion utilisateurs

- une fonction qui renvoie la chaine qui sert de mdp qui a été tapée au clavier matriciel
